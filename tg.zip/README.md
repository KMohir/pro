.env fayl yaratilgan serverga qoyilayotganda  value qilip 
ADMINS="telegramipadressadmins"
BOT_TOKEN=6260268734:AAFeRhqVP3_sBkZN3MYbvF70uRqg5CtZ25M    or   "your bot token"
ip=localhost            ip-xost manzili uchun
operator="telegramipadressoperator"     
