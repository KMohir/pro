from .help import dp
from .support import dp
from .support_call import dp
from .start import dp
from .echo import dp

__all__ = ["dp"]
